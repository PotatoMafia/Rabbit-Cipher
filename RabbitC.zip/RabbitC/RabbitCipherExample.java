import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class RabbitCipherExample {
    public static void main(String[] args) {
        String inputFile = "input.txt";
        String encryptedFile = "encrypted.txt";
        String decryptedFile = "decrypted.txt";
        String key = "mysecretkey12345";
        byte[] iv = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };

        RabbitCipher rabbitCipher = new RabbitCipher();

        // Set up the key and IV
        rabbitCipher.setupKey(key.getBytes());
        rabbitCipher.setupIV(iv);

        // Encrypt the file
        try {
            FileInputStream fis = new FileInputStream(inputFile);
            FileOutputStream fos = new FileOutputStream(encryptedFile);

            byte[] buffer = new byte[1024];
            int bytesRead;

            while ((bytesRead = fis.read(buffer)) != -1) {
                byte[] encryptedBytes = rabbitCipher.crypt(Arrays.copyOf(buffer, bytesRead));
                fos.write(encryptedBytes);
            }

            fis.close();
            fos.close();

            System.out.println("File encrypted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Decrypt the file
        rabbitCipher.reset();
        rabbitCipher.setupKey(key.getBytes());
        rabbitCipher.setupIV(iv);

        try {
            FileInputStream fis = new FileInputStream(encryptedFile);
            FileOutputStream fos = new FileOutputStream(decryptedFile);

            byte[] buffer = new byte[1024];
            int bytesRead;

            while ((bytesRead = fis.read(buffer)) != -1) {
                byte[] decryptedBytes = rabbitCipher.crypt(Arrays.copyOf(buffer, bytesRead));
                fos.write(decryptedBytes);
            }

            fis.close();
            fos.close();

            System.out.println("File decrypted successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
